#!/bin/bash

echo "=== Установка AdGuard VPN Manager ==="

# URL последнего релиза
DOWNLOAD_URL="https://github.com/mashakulina/AdGuardVPN_Manager/releases/latest/download/adguardvpn_manager.tar.gz"
INSTALL_DIR="$HOME/AdGuard VPN Manager"
TEMP_ARCHIVE="/tmp/adguardvpn_manager.tar.gz"

# Создаем директорию установки
echo "📁 Создание директории установки..."
mkdir -p "$INSTALL_DIR"

# Скачиваем архив
echo "📥 Скачивание AdGuard VPN Manager..."
if wget -q "$DOWNLOAD_URL" -O "$TEMP_ARCHIVE"; then
    echo "✅ Архив успешно скачан"
else
    echo "❌ Ошибка скачивания архива"
    exit 1
fi

# Распаковываем архив
echo "📦 Распаковка архива..."
if tar -xzf "$TEMP_ARCHIVE" -C "$INSTALL_DIR"; then
    echo "✅ Архив распакован"
else
    echo "❌ Ошибка распаковки архива"
    exit 1
fi

# Удаляем временный архив
rm -f "$TEMP_ARCHIVE"

# Создаем ярлыки
echo "📋 Создание ярлыков..."

# Функция для создания .desktop файла
create_desktop_file() {
    local manager_dir="$INSTALL_DIR"
    local main_script="$manager_dir/main.py"
    local icon_path="$manager_dir/ico/adguard.png"

    # Проверяем существование файлов
    if [[ ! -f "$main_script" ]]; then
        echo "❌ Основной скрипт менеджера не найден"
        return 1
    fi

    if [[ ! -f "$icon_path" ]]; then
        echo "❌ Иконка менеджера не найдена"
        return 1
    fi

    # Содержимое .desktop файла
    desktop_content="[Desktop Entry]
Encoding=UTF-8
Version=1.0
Type=Application
Name=AdGuard VPN Manager
GenericName=AdGuard VPN Manager
Comment=GUI Manager for AdGuard VPN on Linux
Exec=python3 \"$main_script\"
Icon=$icon_path
Categories=Network;VPN;
Keywords=vpn;adguard;security;privacy;
Terminal=false
StartupNotify=true
StartupWMClass=AdGuardVPNManager
MimeType=
X-GNOME-UsesNotifications=true
InitialPreference=9
OnlyShowIn=GNOME;XFCE;KDE;
"

    # Создаем на рабочем столе
    desktop_created=false
    desktop_paths=(
        "$HOME/Рабочий стол/AdGuard_VPN_Manager.desktop"
        "$HOME/Desktop/AdGuard_VPN_Manager.desktop"
    )

    for desktop_path in "${desktop_paths[@]}"; do
        desktop_dir=$(dirname "$desktop_path")
        if [[ -d "$desktop_dir" ]]; then
            echo "$desktop_content" > "$desktop_path"
            chmod 755 "$desktop_path"
            echo "✅ Ярлык создан: $desktop_path"
            desktop_created=true
            break
        fi
    done

    if [[ "$desktop_created" == false ]]; then
        echo "⚠️ Не удалось создать ярлык на рабочем столе"
    fi

    # Создаем в меню приложений
    local_apps_dir="$HOME/.local/share/applications"
    applications_path="$local_apps_dir/AdGuard_VPN_Manager.desktop"

    mkdir -p "$local_apps_dir"
    echo "$desktop_content" > "$applications_path"
    chmod 644 "$applications_path"
    echo "✅ Добавлено в меню приложений: $applications_path"

    # Обновляем кэш desktop
    if command -v update-desktop-database >/dev/null 2>&1; then
        update-desktop-database "$local_apps_dir"
        echo "✅ Кэш меню приложений обновлен"
    else
        echo "⚠️ Команда update-desktop-database не найдена"
    fi

    return 0
}

# Вызываем функцию создания ярлыков
create_desktop_file

# Автоматический запуск менеджера
echo "🚀 Запуск AdGuard VPN Manager..."
cd "$INSTALL_DIR"

# Проверяем наличие Python3
if ! command -v python3 >/dev/null 2>&1; then
    echo "❌ Python3 не установлен. Установите Python3 для запуска менеджера."
    echo "📁 Установка завершена! Запустите менеджер вручную из меню приложений."
    exit 0
fi

# Проверяем наличие основного скрипта
if [[ ! -f "main.py" ]]; then
    echo "❌ Основной скрипт main.py не найден"
    echo "📁 Установка завершена! Проверьте содержимое папки $INSTALL_DIR"
    exit 0
fi

# Запускаем менеджер в фоне
echo "🎉 Запускаем AdGuard VPN Manager..."
nohup python3 main.py > /dev/null 2>&1 &

# Даем время на запуск
sleep 2

# Проверяем запустился ли процесс
if pgrep -f "python3.*main.py" > /dev/null; then
    echo "✅ AdGuard VPN Manager успешно запущен"
    echo "📊 PID процесса: $(pgrep -f "python3.*main.py")"
else
    echo "⚠️ Не удалось запустить AdGuard VPN Manager автоматически"
    echo "💡 Запустите вручную: python3 \"$INSTALL_DIR/main.py\""
fi

echo ""
echo "🎉 Установка завершена!"
echo "📁 Файлы установлены в: $INSTALL_DIR"
echo "🚀 AdGuard VPN Manager запущен и готов к работе"
